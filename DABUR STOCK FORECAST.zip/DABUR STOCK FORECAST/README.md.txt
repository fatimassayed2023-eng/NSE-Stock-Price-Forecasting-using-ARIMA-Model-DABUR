# NSE Stock Price Forecasting using ARIMA Model (DABUR)

## Project Overview

This project performs time series analysis and forecasting on the NSE listed stock **Dabur India Limited (DABUR)** using the ARIMA (Auto Regressive Integrated Moving Average) model. The objective is to analyze historical stock price data and predict future closing prices.

The project covers data preprocessing, stationarity testing, ARIMA model implementation, and 30-day price forecasting.

---

## Dataset

Source: NSE Historical Data

Stock: DABUR (NSE)

Period Used: Last 1 Year Daily Closing Prices

Data fields used:

• Date  
• Open  
• High  
• Low  
• Close  
• Volume  

Dataset file included:

DABUR_stock_data.csv


---

## Tools and Libraries Used

Python

Google Colab

Libraries:

• pandas  
• numpy  
• matplotlib  
• statsmodels  
• yfinance  

---

## Project Tasks Performed

### 1 Data Preprocessing

The following preprocessing steps were performed:

• Converted Date column into datetime format  
• Set Date as index  
• Checked for missing values  
• Missing values handled using forward fill method  
• Extracted closing price data  

---

### 2 Data Visualization

Closing price trend was plotted to understand stock movement over time.

Observation:

The stock shows gradual fluctuations with some volatility typical of FMCG sector stocks.

---

### 3 Stationarity Testing (ADF Test)

Augmented Dickey Fuller test was performed to check stationarity.

Result interpretation:

• If p value > 0.05 → Non stationary  
• If p value < 0.05 → Stationary  

The series was made stationary using first order differencing.

---

### 4 ACF and PACF Analysis

ACF and PACF plots were used to determine ARIMA parameters.

Selected parameters:

p = 1  
d = 1  
q = 1  

---

### 5 ARIMA Model Implementation

ARIMA(1,1,1) model was trained on closing price data.

Model performance was evaluated by comparing predicted values with actual values.

Observation:

Model shows reasonable fit with historical data.

---

### 6 Future Forecasting

The trained ARIMA model was used to forecast next 30 trading days.

Forecast shows continuation of recent price trends with small variations.

---

## Results

Outputs included:

• Closing price trend graph  
• ADF test result  
• ACF plot  
• PACF plot  
• ARIMA model summary  
• Actual vs Predicted graph  
• 30 day forecast graph  

All output screenshots are included in output folder.

---

## Key Findings

• Stock price data was initially non-stationary  
• Differencing improved stationarity  
• ARIMA model captured short term patterns  
• Forecast indicates moderate variation  
• Time series models depend heavily on past trends  

---

## Limitations

• ARIMA only uses historical price data  
• External market factors not considered  
• News and economic factors not included  
• Predictions are statistical estimates only  

---

## AI Ethics & Responsible Usage Declaration

This project follows responsible AI practices:

• Data used is publicly available NSE stock data  
• No personal or confidential data used  
• Model developed only for academic learning  
• No financial decision should be based on this model  
• Results are statistical predictions only  
• No bias or manipulation done in analysis  

This work follows principles of transparency, fairness and responsible AI usage.

---

## Academic Integrity Declaration

This project is my original work.

All references and libraries used are properly acknowledged.

No plagiarism has been done.

---

## Conclusion

This project demonstrates how ARIMA time series models can be applied to stock price forecasting. The model successfully analyzed historical trends and generated future price predictions.

This project helped in understanding:

• Time series preprocessing  
• Stationarity concepts  
• ARIMA modeling  
• Forecasting techniques  
• Data visualization  

---

## Author

Student Name: FATIMA SAYYED
Course: AI & Data Science  
Subject: Data Analytics Visualization  
College: RIZVI COLLEGE OF ENGINEERING
